#pragma once

#include "leia/device/api.h"

BEGIN_CAPI_DECL

LEIADEVICE_API
const char* leiaDeviceGetVersion();

END_CAPI_DECL
