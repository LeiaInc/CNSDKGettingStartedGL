#pragma once

#ifndef LHT_SERVICE_EXPORTS
# define LHT_SERVICE_EXPORTS
#endif
