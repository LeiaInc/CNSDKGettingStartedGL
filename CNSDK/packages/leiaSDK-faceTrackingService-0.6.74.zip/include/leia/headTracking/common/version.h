#pragma once

#include "leia/headTracking/common/api.h"

BEGIN_CAPI_DECL

LHT_COMMON_API
const char* leiaHeadTrackingGetVersion();

END_CAPI_DECL
