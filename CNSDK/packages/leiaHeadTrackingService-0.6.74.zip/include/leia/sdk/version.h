#pragma once

#include "leia/sdk/api.h"

BEGIN_CAPI_DECL

LEIASDK_API
const char* leiaSdkGetVersion();

END_CAPI_DECL
