#pragma once

#include "leia/common/api.h"

LEIA_COMMON_API
const char* leiaCommonGetGitRefspec();

LEIA_COMMON_API
const char* leiaCommonGetGitSha1();
