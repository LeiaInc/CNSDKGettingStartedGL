#pragma once

#ifndef LHT_ENGINE_EXPORTS
# define LHT_ENGINE_EXPORTS
#endif

#ifndef LHT_HAS_REALSENSE
# define LHT_HAS_REALSENSE
#endif
